onResume = function() {
    console.log('onResume called');
}

onResume = function(x) {
    console.log('onResume called with paremeter');
}
window.onResume = function() {
    console.log('onResume called');
}

window.onResume = function(x) {
    console.log('onResume called with paremeter');
}