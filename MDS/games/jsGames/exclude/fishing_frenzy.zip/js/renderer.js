function renderUI() {
    if (gameobjects.gamestate == gameobjects.states.loading) //LOADING
    {
        spriteFont.drawText('LOADING IS COMPLETE\nPRESS OK BUTTON', { x: 520, y: 400 });
    } else if (gameobjects.gamestate == gameobjects.states.home) //home
    {
        context.drawImage(img.GameLogo, GUI.gamelogo.x, GUI.gamelogo.y, GUI.gamelogo.width, GUI.gamelogo.height);
        context.drawImage(img.Button, GUI.playMenu.x + GUI.btnCommon.x + 200 * homeScreenPointerPos, GUI.playMenu.y + 150 + GUI.btnPlay.y, GUI.btnPointer.width, GUI.btnPointer.height);
        for (var i = 0; i < homeScreenButtonList.length; i++) {
            context.drawImage(homeScreenButtonList[i], GUI.playMenu.x + GUI.btnCommon.x + 200 * i, GUI.playMenu.y + GUI.btnCommon.y, GUI.btnCommon.width, GUI.btnCommon.height);
        }
    } else if (gameobjects.gamestate == gameobjects.states.pause) //pause
    {
        context.drawImage(img.Paused, GUI.gamelogo.x, GUI.gamelogo.y, GUI.gamelogo.width, GUI.gamelogo.height);
        context.drawImage(img.Button, GUI.pauseMenu.x + GUI.btnCommon.x + 200 * pauseScreenPointerPos, GUI.pauseMenu.y + 150 + GUI.btnPlay.y, GUI.btnPointer.width, GUI.btnPointer.height);
        for (var i = 0; i < pauseScreenButtonList.length; i++) {
            context.drawImage(pauseScreenButtonList[i], GUI.pauseMenu.x + GUI.btnCommon.x + 200 * i, GUI.pauseMenu.y + GUI.btnCommon.y, GUI.btnCommon.width, GUI.btnCommon.height);
        }
    } else if (gameobjects.gamestate == gameobjects.states.play) //play
    {
        context.drawImage(img.Frame2, 70, 0, 1450, 70);
        context.drawImage(img.Frame, 70 + 700 / 2, 930, 1450 - 700, 70);
        if (gameobjects.player.worms < 1)
            spriteFont.drawText('NEED WORMS!!', { x: gameobjects.defaults.warnings.x, y: gameobjects.defaults.warnings.y });
        spriteFont.drawText('TARGET:' + gameobjects.player.target, { x: 100, y: 5 });
        spriteFont.drawText('SCORE:' + gameobjects.player.score, { x: 480, y: 5 });
        spriteFont.drawText('LEVEL:' + gameobjects.player.level, { x: 800, y: 5 });
        spriteFont.drawText('TIME:' + gameobjects.player.time.toString().toHHMMSS(), { x: 1100, y: 5 });
        spriteFont.drawText('BOMBS:' + gameobjects.player.bombs, { x: 480, y: 950 });
        spriteFont.drawText('WORMS:' + gameobjects.player.worms, { x: 850, y: 950 });
        context.drawImage(img.LevelUp, GUI.levelup.x, GUI.levelup.y, GUI.levelup.width, GUI.levelup.height);
    } else if (gameobjects.gamestate == gameobjects.states.overfail) // overfailed
    {
        context.drawImage(img.TimeOver, GUI.gamelogo.x, GUI.gamelogo.y, GUI.gamelogo.width, GUI.gamelogo.height);
        spriteFont.drawText('HIGH SCORE:' + gameobjects.player.HighScore, { x: 550, y: 400 });
        spriteFont.drawText('YOUR SCORE:' + gameobjects.player.lastScore, { x: 550, y: 500 });
        spriteFont.drawText('TIME IS OVER\nPRESS OK BUTTON TO GO BACK TO MAIN MENU', { x: 250, y: 600 });
    } else if (gameobjects.gamestate == gameobjects.states.info) // info
    {
        spriteFont.drawText('PRESS DOWN BUTTON FOR FISHING\n PRESS UP BUTTON TO DROP BOMBS\n PRESS LEFT BUTTON TO MOVE LEFT\n PRESS RIGHT BUTTON TO MOVE RIGHT', { x: 320, y: 200 });
        spriteFont.drawText('PRESS OK BUTTON TO GO BACK TO MAIN MENU', { x: 250, y: 600 });
    }
}

function renderGlobalElements() {

    context.drawImage(img.Sky, scrollength, 0, gameobjects.background.width, 460);
    context.drawImage(img.Sky, gameobjects.background.width + scrollength, 0, gameobjects.background.width, 460);
    context.drawImage(img.Sky, gameobjects.background.width * 2 + scrollength, 0, gameobjects.background.width, 460);

    context.drawImage(img.PlayerHandRot, gameobjects.player.x + 155, gameobjects.player.y + 30, gameobjects.player.width / 1.5, gameobjects.player.height);
    context.drawImage(img.PlayerBody, gameobjects.player.x + 110, gameobjects.player.y + 95, gameobjects.player.width / 5, gameobjects.player.height - 50);
    context.drawImage(img.Boat, gameobjects.player.x + 20, gameobjects.player.y + 110, gameobjects.player.width / 1.2, gameobjects.player.height - 20);

    context.drawImage(img.PlayerHandPaddle, gameobjects.player.x + 110, gameobjects.player.y + 88, gameobjects.player.width / 4, gameobjects.player.height);
    context.drawImage(img.PlayerHead_0, gameobjects.player.x + 100, gameobjects.player.y + 25, gameobjects.player.width / 4, gameobjects.player.height / 1.3);

    context.drawImage(img.Background, scrollength, gameobjects.background.y, gameobjects.background.width, gameobjects.background.height);
    context.drawImage(img.Background, gameobjects.background.width + scrollength, gameobjects.background.y, gameobjects.background.width, gameobjects.background.height);
    context.drawImage(img.Background, gameobjects.background.width * 2 + scrollength, gameobjects.background.y, gameobjects.background.width, gameobjects.background.height);

    for (let i = 0; i < bubbles.length; i++) {
        context.drawImage(img.Bubble, bubbles[i].x, bubbles[i].y, bubbles[i].width, bubbles[i].height);
    }

    context.drawImage(img.Underwater, 0, 650, gameobjects.background.width, 300);
    context.drawImage(img.Underwater, gameobjects.background.width, 650, gameobjects.background.width, 300);

    context.drawImage(img.Ground, 0, 900, gameobjects.background.width, 100);
    context.drawImage(img.Ground, gameobjects.background.width, 900, gameobjects.background.width, 100);

    context.beginPath();
    context.strokeStyle = '#bccdd2';
    context.lineWidth = 1;
    context.moveTo(gameobjects.hook.x + 10, gameobjects.player.y + 45);
    context.lineTo(gameobjects.hook.x + 10, gameobjects.hook.y);
    context.stroke();

    context.drawImage(img.Plumb, gameobjects.hook.x + 5, gameobjects.player.y + 50, gameobjects.hook.width / 2, gameobjects.hook.height / 2);
    if (gameobjects.player.worms > 0)
        context.drawImage(img.Worm_0, gameobjects.hook.x, gameobjects.hook.y + 20, gameobjects.hook.width * 2, gameobjects.hook.height * 2);
    context.drawImage(img.Hook, gameobjects.hook.x - 4, gameobjects.hook.y, gameobjects.hook.width * 1.5, gameobjects.hook.height * 2);

    if (caught) {
        context.save();
        context.translate(gameobjects.hook.x + caught.width / 2, gameobjects.hook.y + caught.height / 2);
        context.rotate(-80);
        context.translate(-(gameobjects.hook.x + caught.width / 2), -(gameobjects.hook.y + caught.height / 2));
        context.drawImage(img[caught.fishtype], gameobjects.hook.x, gameobjects.hook.y + 20, caught.width - 10, caught.height + 10);
        context.restore();
    }

    for (let i = 0; i < fishes.length; i++) {
        if (fishes[i].xdir == -1)
            context.drawImage(img[fishes[i].fishtype], fishes[i].x, fishes[i].y, fishes[i].width, fishes[i].height);
        else {
            context.save();
            context.scale(-1, 1);
            context.drawImage(img[fishes[i].fishtype], -(fishes[i].width + fishes[i].x), fishes[i].y, fishes[i].width, fishes[i].height);
            context.restore();
        }
    }

    for (let i = 0; i < sharks.length; i++) {
        if (sharks[i].xdir == -1)
            context.drawImage(img.Shark_0, sharks[i].x, sharks[i].y, sharks[i].width, sharks[i].height);
        else {
            context.save();
            context.scale(-1, 1);
            context.drawImage(img.Shark_0, -(sharks[i].width + sharks[i].x), sharks[i].y, sharks[i].width, sharks[i].height);
            context.restore();
        }
    }

    for (let i = 0; i < collectables.length; i++) {
        context.drawImage(collectables[i].image, collectables[i].x, collectables[i].y, collectables[i].size, collectables[i].size);
    }

    for (let i = 0; i < bombs.length; i++) {
        context.drawImage(img.Bomb, bombs[i].x, bombs[i].y, bombs[i].width, bombs[i].height);
    }
    for (let i = 0; i < blasts.length; i++) {
        if (blasts[i].frameIndex > blasts[i].frames.length - 1) {
            blasts.splice(i, 1);
        } else {
            context.drawImage(blasts[i].frames[parseInt(blasts[i].frameIndex)], blasts[i].x, blasts[i].y, blasts[i].width, blasts[i].height);
            blasts[i].frameIndex += 0.2;
        }
    }
}